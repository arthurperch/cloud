def handler(event, context):
    return {"statusCode": 200, "body": "hello from lab a3"}
